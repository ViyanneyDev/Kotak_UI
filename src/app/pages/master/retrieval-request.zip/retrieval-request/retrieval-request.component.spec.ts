import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RetrievalRequestComponent } from './retrieval-request.component';

describe('RetrievalRequestComponent', () => {
  let component: RetrievalRequestComponent;
  let fixture: ComponentFixture<RetrievalRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RetrievalRequestComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RetrievalRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
